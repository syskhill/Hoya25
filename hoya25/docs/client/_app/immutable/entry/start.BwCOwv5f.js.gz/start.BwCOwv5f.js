import{f as a}from"../chunks/Dddn1_z5.js";export{a as start};
