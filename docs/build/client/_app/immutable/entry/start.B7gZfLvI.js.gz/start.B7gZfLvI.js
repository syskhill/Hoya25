import{f as a}from"../chunks/CwjIEIhY.js";export{a as start};
